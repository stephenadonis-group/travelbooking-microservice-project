resource "aws_ecr_repository" "travelbooking" {
  name                 = var.repository_name
  image_tag_mutability = "MUTABLE"

  force_delete = true

  image_scanning_configuration {
    scan_on_push = true
  }

  encryption_configuration {
    encryption_type = "AES256"
  }

  tags = {
    Name        = var.repository_name
    Project     = "TravelBooking"
    Environment = "Production"
  }
}