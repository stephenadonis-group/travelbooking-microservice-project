variable "repository_name" {
  description = "Amazon ECR Repository Name"
  type        = string
}